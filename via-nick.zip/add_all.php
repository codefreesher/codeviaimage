<?
include "sql.php";
$data=file_get_contents("data/all_web.txt");
$data=str_replace("\r","",$data);
$data=explode("\n",$data);

writeCountry(array());

for($i=0;$i<count($data);$i++)
{
    $mdata=$data[$i];
    $mdata=explode("[l]",$mdata);
    $ct=array();
    $ct['country']=$mdata[0];
    $ct['mobile']=0;
    $ct['l1']=$mdata[2];
    $ct['l2']=$mdata[3];
    $ct['l3']=$mdata[4];
    $ct['l4']=$mdata[5];
    $ct['l5']=$mdata[6];
    $ct['l6']=$mdata[7];
    $ct['l7']=$mdata[8];
    $ct['l8']=$mdata[9];
    $ct['l9']=$mdata[10];
    addContry($ct);
}

?>