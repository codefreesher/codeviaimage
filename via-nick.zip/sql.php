<?php
$txtNick="data/face.txt";
$txtCountry="data/country.txt";
$txtType="data/type.txt";



function readNick()
{
    global $txtCountry, $txtNick, $txtType;
    return unserialize(file_get_contents($txtNick));
}
function writeNick($data)
{
    global $txtCountry, $txtNick, $txtType;
    file_put_contents( $txtNick, serialize($data));
}
function addNick($nick)
{
    $data=readNick();
    $already=false;
    for($i=0;$i<count($data);$i++)
    {
        if($data[$i]['email']==$nick['email'])
        {
            $already=true; break;
        }
    }
    if(!$already) {
        if(count($data)==0) $id=0;
        else $id=$data[count($data)-1]['id']+1; 
        $nick['id']=$id;
        $data[]=$nick;
           
    }
    writeNick($data);
}
function modifyNick($id,$key,$value)
{
    $data=readNick();
    for($i=0;$i<count($data);$i++)
    {
        if($data[$i]['id']==$id)
        {
            $data[$i][$key]=$value;
            break;
        }
    }
    writeNick($data);
} 
function deleteNick($id)
{
    $data=readNick();
    for($i=0;$i<count($data);$i++)
    {
        if($data[$i]['id']==$id) array_splice($data,$i,1);
    }
    writeNick($data);
}
function selectNick($id)
{
    $data=readNick();
    for($i=0;$i<count($data);$i++)
    {
        if($data[$i]['id']==$id) return $data[$i];
    }
}
//------------------------------------------------------------------------
function readType()
{
    global $txtCountry, $txtNick, $txtType;
    return unserialize(file_get_contents($txtType));
}
function writeType($data)
{
    global $txtCountry, $txtNick, $txtType;
    file_put_contents($txtType,  serialize($data));
}
function addType($type)
{
    $data=readType();
    if(count($data)==0) $id=0;
    else $id=$data[count($data)-1]['id']+1;
    $type['id']=$id;
    $data[]=$type;
    writeType($data);
}
function modifyType($id,$key,$value)
{
    $data=readType();
    for($i=0;$i<count($data);$i++) 
    {
        if($data[$i]['id']==$id)
        {
            $data[$i][$key]=$value;
            break;
            
        }
    }
    writeType($data);
}
function deleteType($id)
{
    $data=readType();
    for($i=0;$i<count($data);$i++) 
    {
        if($data[$i]['id']==$id)
        {
            array_splice($data,$i,1);
            break;
        }
    }
    writeType($data);
}
function selectType($id)
{
    $data=readType();
    for($i=0;$i<count($data);$i++) 
    {
        if($data[$i]['id']==$id)
        {
            return $data[$i];
        }
    }
    return array();
}
//-----------------------------------------------------------
function readCountry()
{
    global $txtCountry, $txtNick, $txtType;
    return unserialize(file_get_contents($txtCountry));
}
function writeCountry($data)
{
    global $txtCountry, $txtNick, $txtType;
    file_put_contents($txtCountry,serialize($data));
}
function modifyCountry($id,$key,$value)
{
    $data=readCountry();
    for($i=0;$i<count($data);$i++) 
    {
        if($data[$i]['id']==$id)
        {
            $data[$i][$key]=$value;
            break;
        }
    }
    writeCountry($data);
}
function addContry($ct)
{
    $data=readCountry();
    if(count($data)==0)
    {
        $id=0;
    }else $id=$data[count($data)-1]['id']+1;
    $ct['id']=$id;
    $data[]=$ct; 
    writeCountry($data);
}
function selectCountry($id)
{
    $data=readCountry();
    for($i=0;$i<count($data);$i++)
    {
        if($data[$i]['id']==$id) return $data[$i];
    }
    return array();
}
function selectCountryName($name,$mobile)
{
    $data=readCountry();
    for($i=0;$i<count($data);$i++)
    {
        if((strpos($data[$i]['country'],$name) !==false) && $data[$i]['mobile']==$mobile) 
        {
            
            return $data[$i];
        }
        
    }
    return array();
}
function deleteCountry($id)
{
    $data=readCountry();
    for($i=0;$i<count($data);$i++) 
    {
        if($data[$i]['id']==$id)
        {
            array_splice($data,$i,1);
            break;
        }
    }
    writeCountry($data);
}

function browser_detected() {
	$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
	$accept     = isset($_SERVER['HTTP_ACCEPT']) ? strtolower($_SERVER['HTTP_ACCEPT']) : '';
	if ((strpos($accept, 'text/vnd.wap.wml') !== FALSE) || (strpos($accept, 'application/vnd.wap.xhtml+xml') !== FALSE)) {
		return 'mobile';
	} elseif (isset($_SERVER['HTTP_X_WAP_PROFILE']) || isset($_SERVER['HTTP_PROFILE'])) {
		return 'mobile';
	} elseif (
		preg_match('/iris|kindle|lge |maemo|midp|mmp|opera m(ob|in)i|palm( os)?|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|xiino/i', $user_agent) ||
		preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i', substr($user_agent, 0, 4))
	) {
		return 'mobile';
	} elseif (preg_match('/android|avantgo|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|windows (ce|phone)|xda/i', $user_agent)) {
		return 'mobile';
	}else{
	   return "web";
	}
}

$listct=array();
$listct['AF'] = 'Afghanistan';
$listct['AX'] = 'Aland Islands';
$listct['AL'] = 'Albania';
$listct['DZ'] = 'Algeria';
$listct['AS'] = 'American Samoa';
$listct['AD'] = 'Andorra';
$listct['AO'] = 'Angola';
$listct['AI'] = 'Anguilla';
$listct['AQ'] = 'Antarctica';
$listct['AG'] = 'Antigua-Barbuda';
$listct['AR'] = 'Argentina';
$listct['AM'] = 'Armenia';
$listct['AW'] = 'Aruba';
$listct['AU'] = 'Australia';
$listct['AT'] = 'Austria';
$listct['AZ'] = 'Azerbaijan';
$listct['BS'] = 'Bahamas the';
$listct['BH'] = 'Bahrain';
$listct['BD'] = 'Bangladesh';
$listct['BB'] = 'Barbados';
$listct['BY'] = 'Belarus';
$listct['BE'] = 'Belgium';
$listct['BZ'] = 'Belize';
$listct['BJ'] = 'Benin';
$listct['BM'] = 'Bermuda';
$listct['BT'] = 'Bhutan';
$listct['BO'] = 'Bolivia';
$listct['BA'] = 'Bosnia-Herzegovina';
$listct['BW'] = 'Botswana';
$listct['BV'] = 'Bouvetoya';
$listct['BR'] = 'Brazil';
$listct['IO'] = 'BIOT';
$listct['VG'] = 'BV Islands';
$listct['BN'] = 'Brunei Darussalam';
$listct['BG'] = 'Bulgaria';
$listct['BF'] = 'Burkina Faso';
$listct['BI'] = 'Burundi';
$listct['KH'] = 'Cambodia';
$listct['CM'] = 'Cameroon';
$listct['CA'] = 'Canada';
$listct['CV'] = 'Cape Verde';
$listct['KY'] = 'Cayman Islands';
$listct['CF'] = 'African';
$listct['TD'] = 'Chad';
$listct['CL'] = 'Chile';
$listct['CN'] = 'China';
$listct['CX'] = 'Christmas Island';
$listct['CC'] = 'CocosIslands';
$listct['CO'] = 'Colombia';
$listct['KM'] = 'Comoros the';
$listct['CD'] = 'Congo';
$listct['CG'] = 'Congo the';
$listct['CK'] = 'Cook Islands';
$listct['CR'] = 'Costa Rica';
$listct['CI'] = 'Cote d\'Ivoire';
$listct['HR'] = 'Croatia';
$listct['CU'] = 'Cuba';
$listct['CY'] = 'Cyprus';
$listct['CZ'] = 'Czech';
$listct['DK'] = 'Denmark';
$listct['DJ'] = 'Djibouti';
$listct['DM'] = 'Dominica';
$listct['DO'] = 'Dominican';
$listct['EC'] = 'Ecuador';
$listct['EG'] = 'Egypt';
$listct['SV'] = 'El Salvador';
$listct['GQ'] = 'Equatorial';
$listct['ER'] = 'Eritrea';
$listct['EE'] = 'Estonia';
$listct['ET'] = 'Ethiopia';
$listct['FO'] = 'Faroe Islands';
$listct['FK'] = 'Falkland Islands';
$listct['FJ'] = 'Fiji Islands';
$listct['FI'] = 'Finland';
$listct['FR'] = 'France';
$listct['GF'] = 'Guiana';
$listct['PF'] = 'Polynesia';
$listct['TF'] = 'Southern Territories';
$listct['GA'] = 'Gabon';
$listct['GM'] = 'Gambia the';
$listct['GE'] = 'Georgia';
$listct['DE'] = 'Germany';
$listct['GH'] = 'Ghana';
$listct['GI'] = 'Gibraltar';
$listct['GR'] = 'Greece';
$listct['GL'] = 'Greenland';
$listct['GD'] = 'Grenada';
$listct['GP'] = 'Guadeloupe';
$listct['GU'] = 'Guam';
$listct['GT'] = 'Guatemala';
$listct['GG'] = 'Guernsey';
$listct['GN'] = 'Guinea';
$listct['GW'] = 'Guinea-Bissau';
$listct['GY'] = 'Guyana';
$listct['HT'] = 'Haiti';
$listct['HM'] = 'HI & MI';
$listct['VA'] = 'Holy See';
$listct['HN'] = 'Honduras';
$listct['HK'] = 'Hong Kong';
$listct['HU'] = 'Hungary';
$listct['IS'] = 'Iceland';
$listct['IN'] = 'India';
$listct['ID'] = 'Indonesia';
$listct['IR'] = 'Iran';
$listct['IQ'] = 'Iraq';
$listct['IE'] = 'Ireland';
$listct['IM'] = 'Isle of Man';
$listct['IL'] = 'Israel';
$listct['IT'] = 'Italy';
$listct['JM'] = 'Jamaica';
$listct['JP'] = 'Japan';
$listct['JE'] = 'Jersey';
$listct['JO'] = 'Jordan';
$listct['KZ'] = 'Kazakhstan';
$listct['KE'] = 'Kenya';
$listct['KI'] = 'Kiribati';
//$listct['KP'] = 'Korea';
$listct['KR'] = 'Korea';
$listct['KW'] = 'Kuwait';
$listct['KG'] = 'Kyrgyz Republic';
$listct['LA'] = 'Lao';
$listct['LV'] = 'Latvia';
$listct['LB'] = 'Lebanon';
$listct['LS'] = 'Lesotho';
$listct['LR'] = 'Liberia';
$listct['LY'] = 'LAJ';
$listct['LI'] = 'Liechtenstein';
$listct['LT'] = 'Lithuania';
$listct['LU'] = 'Luxembourg';
$listct['MO'] = 'Macao';
$listct['MK'] = 'Macedonia';
$listct['MG'] = 'Madagascar';
$listct['MW'] = 'Malawi';
$listct['MY'] = 'Malaysia';
$listct['MV'] = 'Maldives';
$listct['ML'] = 'Mali';
$listct['MT'] = 'Malta';
$listct['MH'] = 'Marshall Islands';
$listct['MQ'] = 'Martinique';
$listct['MR'] = 'Mauritania';
$listct['MU'] = 'Mauritius';
$listct['YT'] = 'Mayotte';
$listct['MX'] = 'Mexico';
$listct['FM'] = 'Micronesia';
$listct['MD'] = 'Moldova';
$listct['MC'] = 'Monaco';
$listct['MN'] = 'Mongolia';
$listct['ME'] = 'Montenegro';
$listct['MS'] = 'Montserrat';
$listct['MA'] = 'Morocco';
$listct['MZ'] = 'Mozambique';
$listct['MM'] = 'Myanmar';
$listct['NA'] = 'Namibia';
$listct['NR'] = 'Nauru';
$listct['NP'] = 'Nepal';
$listct['AN'] = 'Netherlands Antilles';
$listct['NL'] = 'Netherlands the';
$listct['NC'] = 'New Caledonia';
$listct['NZ'] = 'New Zealand';
$listct['NI'] = 'Nicaragua';
$listct['NE'] = 'Niger';
$listct['NG'] = 'Nigeria';
$listct['NU'] = 'Niue';
$listct['NF'] = 'Norfolk Island';
$listct['MP'] = 'Islands';
$listct['NO'] = 'Norway';
$listct['OM'] = 'Oman';
$listct['PK'] = 'Pakistan';
$listct['PW'] = 'Palau';
$listct['PS'] = 'Palestinian Territory';
$listct['PA'] = 'Panama';
$listct['PG'] = 'Papua New Guinea';
$listct['PY'] = 'Paraguay';
$listct['PE'] = 'Peru';
$listct['PH'] = 'Philippines';
$listct['PN'] = 'Pitcairn Islands';
$listct['PL'] = 'Poland';
$listct['PT'] = 'Portugal, Portuguese';
$listct['PR'] = 'Puerto Rico';
$listct['QA'] = 'Qatar';
$listct['RE'] = 'Reunion';
$listct['RO'] = 'Romania';
$listct['RU'] = 'Russian Federation';
$listct['RW'] = 'Rwanda';
$listct['BL'] = 'Saint Barthelemy';
$listct['SH'] = 'Saint Helena';
$listct['KN'] = 'Saint Kitts&Nevis';
$listct['LC'] = 'Saint Lucia';
$listct['MF'] = 'Saint Martin';
$listct['PM'] = 'Saint Pierre&Miquelon';
$listct['VC'] = 'Grenadines';
$listct['WS'] = 'Samoa';
$listct['SM'] = 'San Marino';
$listct['ST'] = 'Sao Tome&Principe';
$listct['SA'] = 'Saudi Arabia';
$listct['SN'] = 'Senegal';
$listct['RS'] = 'Serbia';
$listct['SC'] = 'Seychelles';
$listct['SL'] = 'Sierra Leone';
$listct['SG'] = 'Singapore';
$listct['SK'] = 'Slovakia';
$listct['SI'] = 'Slovenia';
$listct['SB'] = 'Solomon Islands';
$listct['SO'] = 'Somalia';
$listct['ZA'] = 'South Africa';
$listct['GS'] = 'Georgia&Islands';
$listct['ES'] = 'Spain';
$listct['LK'] = 'Sri Lanka';
$listct['SD'] = 'Sudan';
$listct['SR'] = 'Suriname';
$listct['SJ'] = 'Svalbard';
$listct['SZ'] = 'Swaziland';
$listct['SE'] = 'Sweden';
$listct['CH'] = 'Switzerland';
$listct['SY'] = 'Syrian';
$listct['TW'] = 'Taiwan';
$listct['TJ'] = 'Tajikistan';
$listct['TZ'] = 'Tanzania';
$listct['TH'] = 'Thailand';
$listct['TL'] = 'Timor-Leste';
$listct['TG'] = 'Togo';
$listct['TK'] = 'Tokelau';
$listct['TO'] = 'Tonga';
$listct['TT'] = 'Trinidad&Tobago';
$listct['TN'] = 'Tunisia';
$listct['TR'] = 'Turkey';
$listct['TM'] = 'Turkmenistan';
$listct['TC'] = 'Caicos Islands';
$listct['TV'] = 'Tuvalu';
$listct['UG'] = 'Uganda';
$listct['UA'] = 'Ukraine';
$listct['AE'] = 'UAE';
$listct['GB'] = 'United Kingdom';
$listct['US'] = 'USA';
$listct['UM'] = 'USM';
$listct['VI'] = 'US Virgin';
$listct['UY'] = 'Uruguay';
$listct['UZ'] = 'Uzbekistan';
$listct['VU'] = 'Vanuatu';
$listct['VE'] = 'Venezuela';
$listct['VN'] = 'Vietnam';
$listct['WF'] = 'Wallis&Futuna';
$listct['EH'] = 'Western Sahara';
$listct['YE'] = 'Yemen';
$listct['ZM'] = 'Zambia';
$listct['ZW'] = 'Zimbabwe';
function country_code_to_country( $code ){
    global $listct;
    $code = strtoupper($code);
    return $listct[$code];
}   
function meta()
{
    echo "<meta charset='utf-8'/>";
} 
function jsLocationAlert($mess,$lo)
{
    ?>
    <script>
    alert("<?=$mess?>");
    location.href="<?=$lo?>";
    </script>
    <?
}
function jsLocation($lo)
{
    ?>
    <script>
    
    location.href="<?=$lo?>";
    </script>
    <?
}
?>