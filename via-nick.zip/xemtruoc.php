<?
include "sql.php";
$id=isset($_GET['id'])?$_GET['id']:"0";

$ct=selectCountry($id);
$mobile=$ct['mobile'];
if($mobile==1)
{
    include "mobi.php";
}else{
    include "web.php";
}

?>