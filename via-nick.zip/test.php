<?
include "sql.php";
//writeCountry(array());
//$ct=array();
//$ct['country']="VN";
//$ct['mobile']=0;
//$ct['l1']="Đăng ký";
//$ct['l2']="Đăng nhập Facebook";
//$ct['l3']="Bạn phải đăng nhập để tiếp tục.";
//$ct['l4']="Email hoặc số điện thoại:";
//$ct['l5']="Mật khẩu:";
//$ct['l6']="Duy trì đăng nhập";
//$ct['l7']="Đăng nhập";
//$ct['l8']="Đăng ký Facebook";
//$ct['l9']="Quên mật khẩu?";
//addContry($ct); 
//$ct=array();
//$ct['country']="VN";
//$ct['mobile']=1;
//$ct['l1']="Trước tiên, bạn phải đăng nhập.";
//$ct['l2']="Email hoặc số điện thoại";
//$ct['l3']="Mật khẩu";
//$ct['l4']="Đăng nhập";
//$ct['l5']="Tạo tài khoản mới";
//$ct['l6']="Quên mật khẩu?";
//$ct['l7']="Trung tâm trợ giúp";
//addContry($ct);
////
////
//print_r( readCountry());

//$loai1=array();
//$loai1['name']="Chưa dùng";
//$loai1['color']="green";
//$loai2=array();
//$loai2['name']="Đã dùng";
//$loai2['color']="blue";
//$loai3=array();
//$loai3['name']="Sai Pass";
//$loai3['color']="red";
//$loai4=array();
//$loai4['name']="CheckPoint";
//$loai4['color']="red";
//writeType(array());
//addType($loai1);
//addType($loai2);
//addType($loai3);
//addType($loai4);
//print_r(readType());

?>