<?
//
include "sql.php";

$lang=isset($_GET['lang'])?$_GET['lang']:"auto";
$mobile=isset($_GET['mobile'])?$_GET['mobile']:"auto";
if($lang=="auto")
{
    include "geoiploc.php";
    $ip=$_SERVER['REMOTE_ADDR'];
    $ctName=getCountryFromIP($ip);
}else{
    $ctName=$lang;
}
if($mobile=="auto")
{
    $browser=browser_detected();
    $mobile=($browser=="mobile")?1:0;
}

$ct=selectCountryName($ctName,$mobile);
if(!isset($ct['id']))
{
    $ct=selectCountryName("GB",$mobile); 
}  
if($mobile==1)
{
    include "mobi.php";
}else{
    include "web.php";
}
 
?>