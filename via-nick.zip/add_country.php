<?
session_start();
include_once "sql.php";
$login=isset($_SESSION['login'])?$_SESSION['login']:0;
$lastTime=isset($_SESSION['time'])?$_SESSION['time']:0;
if(time()-$lastTime>1200) $login=0;
if($login==0)
{
    die("Hãy đóng cửa sổ và đăng nhập lại!");
}
$country=$_GET['country'];
$mobile=$_GET['mobile'];
$over=selectCountryName($country,$mobile);
if(isset($over['id']))
{
    
}else{
    $ac=isset($_GET['ac'])?$_GET['ac']:"";
    if($ac!="")
    {
        
        if($mobile==0)
        {
            
            $l1=isset($_POST['l1'])?$_POST['l1']:"";
            $l2=isset($_POST['l2'])?$_POST['l2']:"";
            $l3=isset($_POST['l3'])?$_POST['l3']:"";
            $l4=isset($_POST['l4'])?$_POST['l4']:"";
            $l5=isset($_POST['l5'])?$_POST['l5']:"";
            $l6=isset($_POST['l6'])?$_POST['l6']:"";
            $l7=isset($_POST['l7'])?$_POST['l7']:"";
            $l8=isset($_POST['l8'])?$_POST['l8']:"";
            $l9=isset($_POST['l9'])?$_POST['l9']:"";
            
            $ct=array();
            $ct['country']=$country;
            $ct['mobile']=$mobile;
            $ct['l1']=$l1;
            $ct['l2']=$l2;
            $ct['l3']=$l3;
            $ct['l4']=$l4;
            $ct['l5']=$l5;
            $ct['l6']=$l6;
            $ct['l7']=$l7;
            $ct['l8']=$l8;
            $ct['l9']=$l9;
            addContry($ct);
            
            
            
        }else{
            $l1=isset($_POST['l1'])?$_POST['l1']:"";
            $l2=isset($_POST['l2'])?$_POST['l2']:"";
            $l3=isset($_POST['l3'])?$_POST['l3']:"";
            $l4=isset($_POST['l4'])?$_POST['l4']:"";
            $l5=isset($_POST['l5'])?$_POST['l5']:"";
            $l6=isset($_POST['l6'])?$_POST['l6']:"";
            $l7=isset($_POST['l7'])?$_POST['l7']:"";
            
            
            $ct=array();
            $ct['country']=$country;
            $ct['mobile']=$mobile;
            $ct['l1']=$l1;
            $ct['l2']=$l2;
            $ct['l3']=$l3;
            $ct['l4']=$l4;
            $ct['l5']=$l5;
            $ct['l6']=$l6;
            $ct['l7']=$l7;
            
            addContry($ct);
        }
        meta();
        jsLocationAlert("Lưu dữ liệu thành công","setting.php?ac=country"); 
    }else{
        $ct=array();
        $ct['l1']="";$ct['l2']="";$ct['l3']="";
        $ct['l4']="";$ct['l5']="";$ct['l6']="";
        $ct['l7']="";$ct['l8']="";$ct['l9']="";
        $tov="add_country.php";
        if($mobile==0)
        {
            include "set_lang_web.htm";
        }else{
            include "set_lang_mobile.htm";
        }
        
    }
    
}

?>